#include<iostream>
#include<iomanip>
#include<fstream>
using namespace std;

    
    
      
void manage(int esize,string user,string pwd,int loggedInUserType,int input,string employeeData[][10],string customerData[][10],string customerComplain[][8],string stay,string roomNo,string category,string bookedRooms[],int r,string unbookedRooms,int input1);

void adminLogin(int esize,string user,string pwd,int input,int input1,string employeeData[][10],string customerData[][10],string customerComplain[][8],string stay,string roomNo,string category,int r,string bookedRooms[],int loggedInUserType,string unboookedRooms); void employeeLogin(int esize,string user,string pwd,int input,int input1,string employeeData[][10],string customerData[][10],string customerComplain[][8],string roomNo,string stay,string category,int r,string bookedRooms[],int loggedInUserType,string unbookedRooms);
void employeeLogin(int esize, string user, string pwd, int input, int input1, string employeeData[][10], string customerData[][10], string customerComplain[][8], string roomNo, string category, string stay, int r, string bookedRooms[], int loggedInUserType, string unbookedRooms);
void customerLogin(int esize,string user,string pwd,int input,int input1,string customerData[][10],string customerComplain[][8],string roomNo,string category,string stay,string unbookedRooms,int loggedInUserType,string employeeData[][10],string bookedRooms[],int r);
void rooms(int esize,string user,string pwd,int input,int input1,string unbookedRooms,int r,string bookedRooms[]);
void budget();
void reviews();
void complain(string customerData[][10],string customerComplain[][8]);
bool loadData(string employeeData[][10]);
bool saveData(string employeeData[][10]);
bool deleteData(string employeeData[][10],int esize);

    
int main()
{  
    int esize=10;
    string user,pwd;
    string roomNo,designation;
    string salary,category;
    string stay,date;
    int loggedInUserType=-10;
    int input;
    int input1=-1;
    int r;

    string employeeData[5][10];
    string customerData[4][10];
    string bookedRooms[10];
    string customerComplain[2][8];
    string unbookedRooms;
    
   
    cout<<"*    *    *******    *********    ********    *"<<endl;
    cout<<"*    *   *        *      *        *           *"<<endl;
    cout<<"******  *          *     *        ********    *"<<endl;
    cout<<"*    *   *        *      *        *           *"<<endl;
    cout<<"*    *     ******        *        ********    *******"<<endl;
    cout<<"                                                                                      "<<endl;
    cout<<"         **        **     *******    **      **   *******    *******   ********  **      **  *******  **     **  ********"<<endl;
    cout<<"         *   ****   *    *       *   * *      *  *       *  *       *  *         *  ***   *  *        * *     *      *"<<endl;
    cout<<"         *    **    *    *       *   *  *     *  *       *  *          *         *   **   *  *        *   *   *      *"<<endl;
    cout<<"         *     *    *    *********   *    *   *  *********  *    ***** *******   *    *   *  *******  *    *  *      *"<<endl;
    cout<<"         *          *    *       *   *      * *  *       *  *       *  *         *        *  *        *     * *      *"<<endl;
    cout<<"         *          *    *       *   *        *  *       *   ********  *******   *        *  *******  *       *      *"<<endl; 
    cout<<"                                                                                   "<<endl; 
    cout<<"                           ******   *      *     ******   **********   *********     **      **                     "<<endl;
    cout<<"                          *      *   *    *     *      *      *        *             *  ***  *       "<<endl;
    cout<<"                          *           ****      *             *        *             *   **   *      "<<endl;
    cout<<"                             **        *           **         *        *********     *   **   *             "<<endl; 
    cout<<"                               **      *             **       *        *             *        *            "<<endl;
    cout<<"                          **    *      *        **     *      *        *             *        *           "<<endl;
    cout<<"                             ***       *           ***        *        *********     *        *            "<<endl;
    cout<<"                                        "<<endl;
    manage(esize,user,pwd,loggedInUserType,input,employeeData,customerData, customerComplain, stay, roomNo,category, bookedRooms, r,unbookedRooms,input1);
 }


void manage(int esize, string user, string pwd, int loggedInUserType, int input, string employeeData[][10], string customerData[][10], string customerComplain[][8], string stay, string roomNo, string category, string bookedRooms[], int r, string unbookedRooms, int input1)
{
     cout<<loggedInUserType<<endl;
     cout<<"*******************************************************************************"<<endl;
         cout<<"                 WELCOME  TO   LOGIN   INTERFACE"<<endl;
         cout<<"*******************************************************************************"<<endl;
         cout<<"Choose the desired option:";
         cout << left << setw(5) << "\n"
         << setw(5)<< "1-Administration login"
         <<setw(5)<<"\n"
         <<setw(5)<< "2-Employee login"
         <<setw(5)<<"\n"
         <<setw(5)<< "3-Customer "
         <<setw(5)<<"\n"
         << setw(5)<<"0-Exit";
         cout<<endl;
         
         cin>>input;

         switch(input){
            case 1:
            
                cout<<"Enter the username:"<<endl;
                cin>>user;
                cout<<"Enter the password:"<<endl;
                cin>>pwd;
                if(user=="Administrator"&&pwd=="HMS")
                {
                    loggedInUserType=1;
                }
                else
                {
                    loggedInUserType=-1;
                    cout<<"You have entered invalid credentials"<<endl;
                    manage(esize,user,pwd,loggedInUserType,input,employeeData,customerData, customerComplain, stay, roomNo,category, bookedRooms, r,unbookedRooms,input1);
                }
                break;
            
            case 2:
     cout << "Enter the username:" << endl;
    cin >> user;
    cout << "Enter the password:" << endl;
    cin >> pwd;
    cout<<user<<pwd<<endl;
    cout<<employeeData[0][1]<<employeeData[1][1]<<endl;

    // Check credentials against the employeeData array
    for (int j = 0; j < esize; j++) {
        if (user == employeeData[0][j] && pwd == employeeData[1][j]) {
            loggedInUserType = 2; // Set the user type for employee
            break;
        }
    }

    // If no match was found, handle invalid credentials
    if (loggedInUserType != 2) {
        cout << "Employee not found or invalid credentials." << endl;
        manage(esize, user, pwd, loggedInUserType, input, employeeData, customerData, customerComplain, stay, roomNo, category, bookedRooms, r, unbookedRooms, input1);
    } 
   
    
    break;
            
            case 0:
            
                cout<<"Thank you for using the system"<<endl;
                loggedInUserType=-10;
                break;
            
         }
         if(loggedInUserType==1)
         {
            adminLogin( esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
         }
         else if(loggedInUserType==2)
        {
             employeeLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, roomNo, stay, category, r, bookedRooms, loggedInUserType, unbookedRooms);
        }
         
         else if(loggedInUserType==3)
         {
            customerLogin( esize, user, pwd, input, input1, customerData, customerComplain, roomNo, category, stay, unbookedRooms, loggedInUserType, employeeData,bookedRooms,r);
         }
}
void adminLogin(int esize, string user, string pwd, int input, int input1, string employeeData[][10], string customerData[][10], string customerComplain[][8], string roomNo, string stay, string category, int r, string bookedRooms[], int loggedInUserType, string unbookedRooms)
{
     do{
            cout<<"***************************************************************"<<endl;
            cout<<"         WELCOME   TO    ADMIN     LOGIN"<<endl;
            cout<<"**************************************************************"<<endl;
            cout<<"Choose the desired option";
            cout<< left<<setw(5)<<"\n"
            <<setw(5)<<"1-Data of Employess"
            <<setw(5)<<"\n"
            <<setw(5)<<"2-Data of Customers"
            <<setw(5)<<"\n"
            <<setw(5)<<"3-Rooms"
            <<setw(5)<<"\n"
            <<setw(5)<<"4-Total Budget"
            <<setw(5)<<"\n"
            <<setw(5)<<"5-Customer Reviews"
            <<setw(5)<<"\n"
            <<setw(5)<<"0-Exit"
            <<setw(5)<<"\n";
            
            cout<<"Choose the option"<<endl;
            cin>>input;

             switch(input)
            {
                case 1:
                
                 cout<<"****************************************************************"<<endl;
                cout<<"               DATA   OF   EMPLOYESS"<<endl;
                cout<<"****************************************************************"<<endl;
                cout<<"Choose the desired option:";
                cout<< left<<setw(5)<<"\n"
                <<setw(5)<<"1-Add an employee"
                <<setw(5)<<"\n"
                <<setw(5)<<"2- Delete an employee"
                <<setw(5)<<"\n"
                <<setw(5)<<"3- List of employees"
                <<setw(5)<<"\n"
                <<setw(5)<<"0- Exit"
                <<endl;

                cin>>input1;
                if(input1==1)
                {
                    cout<<"Enter the name of the employee:"<<endl;
                    
                    cout<<"Enter the password you want to assign:"<<endl;
                
                    cout<<"Enter the salary:"<<endl;
                    
                    
                    cout<<"Enter the joining date:"<<endl;

                    cout<<"Enter the designation of the employee:"<<endl;
                    
                   bool a=loadData(employeeData);
                   cout<<a<<endl;
                   bool b=saveData(employeeData);
                   cout<<b<<endl;

                }
                    else if(input1==2)
                    {
                        cout<<"Enter the employee name you want to delete:"<<endl;
                        cin>>user;
                        for(int j=0;j<esize;j++)
                        {
                            if(employeeData[0][j]==user)
                            {
                                employeeData[0][j]="";
                                employeeData[1][j]="";
                                employeeData[2][j]="";
                                employeeData[3][j]="";
                                employeeData[4][j]="";
                                bool c=deleteData(employeeData,esize);
                                
                                
                                cout<<"Employee deleted successfully!"<<endl;
                                break;
                            }
                            else
                            {
                                cout<<"Employee not found:"<<endl;
                                adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                            }
                        }
                        
                    }
                   else  if(input1==3)
                    {
                        cout<<left<<setw(15)<<"Employee Name"
                        
                        <<setw(15)<<"Salary"
                        
                        <<setw(15)<<"Joining Date"
                        
                        <<setw(15)<<"Designation\n";
                        
                        
                        for(int j=0;j<esize;j++)
                        {
                            
                            cout<<left<<setw(15)<<employeeData[0][j]
                            
                            <<setw(15)<<employeeData[2][j]
                            
                            <<setw(15)<<employeeData[3][j]
                        
                            <<setw(15)<<employeeData[4][j];

                        }
                    }
                    else if(input1==0)
                    {
                        cout<<"Thank you"<<endl;
                    adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                    
                    }
                        else
                        {
                            cout<<"Invalid Input"<<endl;
                            adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                        }
                
                 break;
                  case 2:
                
                  cout<<"****************************************************************"<<endl;
                cout<<"               DATA   OF   CUSTOMERS"<<endl;
                cout<<"****************************************************************"<<endl;
                cout<<"Choose the desired option:";
                cout<< left<<setw(5)<<"\n"
                <<setw(5)<<"1-Add a customer"
                <<setw(5)<<"\n"
                <<setw(5)<<"2-List of customers"
                <<setw(5)<<"\n"
                <<setw(5)<<"3-Customer Complains"
                <<setw(5)<<"\n"
                <<setw(5)<<"0- Exit"
                <<setw(5)<<"\n";
                cin>>input1;
                if(input1==1)
                {
                    cout<<"Enter the name of the customer:"<<endl;
                    cin>>user;
                    cout<<"Enter the Room number:"<<endl;
                    cin>>roomNo;
                    r=r+1;
                    cin.ignore(256,'\n');
                    cout<<"Enter the stay duration:"<<endl;
                    getline(cin,stay);
                    cout<<"Enter the room category:"<<endl;
                    cin>>category;
                    for(int j=0;j<esize;j++)
                    {
                        if(customerData[0][j]=="")
                        {
                            customerData[0][j]=user;
                            customerData[1][j]=roomNo;
                            customerData[2][j]=stay;
                            bookedRooms[j]=roomNo;
                            customerData[3][j]=category;
                            cout<<"Customer added successfully!"<<endl;
                            break;
                        }
                        else{
                            cout<<"No room is left"<<endl;
                            adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                        }
                        break;
                    }
                 
                }
               else if (input1==2)
                {
                    cout<<left<<setw(15)<<"Customer Name"
                        <<setw(15)<<"\t"
                        <<setw(15)<<"Room Number"
                        <<setw(15)<<"\t"
                        <<setw(15)<<"Stay Duration"
                        <<setw(15)<<"\t"
                        <<setw(15)<<"Room Category\n";
                        

                        for(int j=0;j<esize;j++)
                        {
                    
                           cout<<left<<setw(15)<<customerData[0][j]
                            <<setw(15)<<"\t"
                            <<setw(15)<<customerData[1][j]
                            <<setw(15)<<"\t"
                            <<setw(15)<<customerData[2][j]
                            <<setw(15)<<"\t"
                            <<setw(15)<<customerData[3][j]
                            <<setw(15)<<"\n";
                        


                        } 
                }
                else if(input1==3)
                {
                    for(int j=0;j<8;j++)
                    {
                    cout<<left<<setw(25)<<customerComplain[0][j]
                    <<setw(25)<<'\n'
                    <<setw(25)<<customerComplain[1][j]
                    <<setw(25)<<"\n";
                    }
                }
                else if(input1==0)
                {
                    cout<<"Thank you"<<endl;
                    adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                }
                else{
                    cout<<"Invalid Input"<<endl;
                    adminLogin(esize, user, pwd, input, input1, employeeData, customerData, customerComplain, stay, roomNo, category, r, bookedRooms, loggedInUserType,unbookedRooms);
                }
                break;
                 case 3:
                 rooms( esize, user, pwd, input, input1, unbookedRooms, r, bookedRooms);
                 break;
                case 4:
                budget();
                break;
                case 5:
                reviews();
                break;
                case 0:
                cout<<"Thank you for using the system"<<endl;
                manage(esize,user,pwd,loggedInUserType,input,employeeData,customerData, customerComplain, stay, roomNo,category, bookedRooms, r,unbookedRooms,input1);
                break;
                default:
                cout<<"Invalid choice"<<endl;
                break;

            }
     }while(input!=0);
}
void employeeLogin(int esize, string user, string pwd, int input, int input1, string employeeData[][10], string customerData[][10], string customerComplain[][8], string roomNo, string category, string stay, int r, string bookedRooms[], int loggedInUserType, string unbookedRooms)
{
do {
        cout << "************************************************************* " << endl;
        cout << "      WELCOME     TO     EMPLOYEE      LOGIN" << endl;
        cout << "************************************************************" << endl;
        cout << "Choose the desired option:" << endl;
        cout << left << setw(5) << "\n"
             << setw(5) << "1-Your Data"
             << setw(5) << "\n"
             << setw(5) << "2-Rooms"
             << setw(5) << "\n"
             << setw(5) << "3-Data of customers"
             << setw(5) << "\n"
             << setw(5) << "4-Customer Reviews"
             << setw(5) << "\n"
             << setw(5) << "5-Total Budget"
             << setw(5) << "\n"
             << setw(5) << "0-Exit"
             << setw(5) << "\n";

        cout << "Choose the option: ";
        cin >> input;

        switch (input) {
            case 1:
                cout << "**********************************************************" << endl;
                cout << "            YOUR      PERSONAL      DATA" << endl;
                cout << "**********************************************************" << endl;
                for (int j = 0; j < esize; j++) {
                    if (user == employeeData[0][j]) {
                        cout << left << setw(25) << "Name \t"
                             << setw(15) << "Salary \t"
                             << setw(15) << "Date of Joining\t "
                             << setw(15) << "Designation\n"
                             << setw(15) << employeeData[0][j]
                             << setw(15) << "\t"
                             << setw(15) << employeeData[2][j]
                             << setw(15) << "\t"
                             << setw(15) << employeeData[3][j]
                             << setw(15) << "\t"
                             << setw(15) << employeeData[4][j];
                        break;
                    }
                }
                break;

            case 2:
                rooms(esize, user, pwd, input, input1, unbookedRooms, r, bookedRooms);
                break;

            case 3:
                do {
                    cout << "****************************************************************" << endl;
                    cout << "               DATA   OF   CUSTOMERS" << endl;
                    cout << "****************************************************************" << endl;
                    cout << "Choose the desired option:" << endl;
                    cout << left << setw(5) << "\n"
                         << setw(5) << "1-Add a customer"
                         << setw(5) << "\n"
                         << setw(5) << "2-List of customers"
                         << setw(5) << "\n"
                         << setw(5) << "3-Customer Complains"
                         << setw(5) << "\n"
                         << setw(5) << "0-Exit"
                         << setw(5) << "\n";
                    cin >> input1;

                    switch (input1) {
                        case 1: {
                            cout << "Enter the name of the customer: ";
                            cin >> user;
                            cout << "Enter the Room number: ";
                            cin >> roomNo;
                            cout << "Enter the stay duration: ";
                            cin.ignore(256, '\n');
                            getline(cin, stay);
                            cout << "Enter the room category: ";
                            cin >> category;

                            bool customerAdded = false;
                            for (int j = 0; j < esize; j++) {
                                if (customerData[0][j].empty()) {
                                    customerData[0][j] = user;
                                    customerData[1][j] = roomNo;
                                    customerData[2][j] = stay;
                                    bookedRooms[j] = roomNo;
                                    customerData[3][j] = category;
                                    cout << "Customer added successfully!" << endl;
                                    customerAdded = true;
                                    break;
                                }
                            }

                            if (!customerAdded) {
                                cout << "No room is left." << endl;
                            }
                            break;
                        }

                        case 2:
                            cout << left << setw(15) << "Customer Name"
                                 << setw(15) << "\t"
                                 << setw(15) << "Room Number"
                                 << setw(15) << "\t"
                                 << setw(15) << "Stay Duration"
                                 << setw(15) << "\t"
                                 << setw(15) << "Room Category\n";

                            for (int j = 0; j < esize; j++) {
                                if (!customerData[0][j].empty()) {
                                    cout << left << setw(15) << customerData[0][j]
                                         << setw(15) << "\t"
                                         << setw(15) << customerData[1][j]
                                         << setw(15) << "\t"
                                         << setw(15) << customerData[2][j]
                                         << setw(15) << "\t"
                                         << setw(15) << customerData[3][j]
                                         << setw(15) << "\n";
                                }
                            }
                            break;

                        case 3:
                            cout << "Customer Complains:" << endl;
                            for (int j = 0; j < 8; j++) {
                                if (!customerComplain[0][j].empty()) {
                                    cout << left << setw(25) << customerComplain[0][j]
                                         << setw(25) << customerComplain[1][j]
                                         << endl;
                                }
                            }
                            break;

                        case 0:
                            cout << "Exiting customer data management." << endl;
                            break;

                        default:
                            cout << "Invalid input. Please try again." << endl;
                    }
                } while (input1 != 0);
                break;

            case 4:
                reviews();
                break;

            case 5:
                budget();
                break;

            case 0:
                manage(esize, user, pwd, loggedInUserType, input, employeeData, customerData, customerComplain, stay, roomNo, category, bookedRooms, r, unbookedRooms, input1);
                break;

            default:
                cout << "Invalid Input. Please try again." << endl;
        }
    } while (input != 0);
}
void customerLogin(int esize,string user,string pwd,int input,int input1,string customerData[][10],string customerComplain[][8],string roomNo,string category,string stay,string unbookedRooms,int loggedInUserType,string employeeData[][10],string bookedRooms[],int r)
{
         cout<<"**************************************************************"<<endl;
         cout<<"      WELCOME  TO  THE  GRANG  MARINE   HOTEL  "<<endl;
         cout<<"**************************************************************"<<endl;
         cout<<"                                                           "<<endl;
         do{
         cout<<left<<setw(5)<<"\n"
         <<setw(5)<<"1-Information about unbooked rooms"
         <<setw(15)<<"\n"
         <<setw(15)<<"2-Customer Reviews"
         <<setw(15)<<"\n"
         <<setw(15)<<"3-Online Booking"
         <<setw(15)<<"\n"
         <<setw(15)<<"4-Cancel Booking"
         <<setw(5)<<"\n"
         <<setw(15)<<"5-Prices "
         <<setw(15)<<"\n"
         <<setw(15)<<"6-Complain"
         <<setw(15)<<"\n"
         <<setw(15)<<"0-Exit"
         <<endl;

         cout<<"Enter your choice"<<endl;
         cin>>input;

         switch(input)
         {
            case 1:
             cout<<"Unbooked rooms are:"<<endl;
            for(int i=0;i<5;i++)
            {
                cout<<unbookedRooms[i]<<endl;

            }
            break;
            case 2:
            reviews();
            break;
            case 3:
            cout<<"Enter your name"<<endl;
            cin>>user;
            cout<<"Enter the duration of stay:"<<endl;
            cin>>stay;
            cout<<"Enter the room category:"<<endl;
            cin>>category;
            cout<<"Enter the room no:"<<endl;
            cin>>roomNo;
            
           
            for (int j= 0; j < esize; j++)
            {
                if(customerData[0][j]=="")
                {
                    customerData[0][j]=user;
                    customerData[1][j]=roomNo;
                    customerData[2][j]=stay;
                    customerData[3][j]=category;
                    cout<<"Thank you for choosing our hotel"<<endl;
                    break;

                }
                else{
                    cout<<"No room is left"<<endl;
                }
            }
            break;
            case 4:
            cout<<"Enter your name"<<endl;
            cin>>user;
            
           
            for (int j= 0; j < esize; j++)
            {
                if(customerData[0][j]=="user")
                {
                    customerData[0][j]="";
                    customerData[2][j]="";
                    cout<<"Your booking is cancelled!"<<endl;
                    break;

                }
               
            }
            break;
            case 5:
            cout<<"Prices for 1 day stay =    Rs. 10000"<<endl;
            cout<<"Prices for 24 hours stay =    Rs. 25000"<<endl;
            cout<<"Prices for 1 week stay  =    Rs. 54000"<<endl;
            cout<<"Prices for  1 month  stay=    Rs. 150000"<<endl;
            break;
            case 6:
            complain(customerData, customerComplain);
            break;
            case 0:
            cout<<"Thank you!"<<endl;
            manage(esize,user,pwd,loggedInUserType,input,employeeData,customerData, customerComplain, stay, roomNo,category, bookedRooms, r,unbookedRooms,input1);
            break;
            default:
            cout<<"Invalid Input"<<endl;
            break;
           
            

            
         }
         }while(input!=0);
}
void budget()
{
    int lastYearProfit=400000;
    int lossOf2022=150000;
    int jan=20000;
    int feb=15000;
    int march=20000;
    int april=40000;
    int may=35000;
    int june=14000;
    int july=25000;
    int august=36000;
    int sep=5000;
    int oct=10000;
    int nov=30000;

                cout<<"*****************************************************************"<<endl;
                cout<<"              BUDGET'S   INFORMATION"<<endl;
                cout<<"*****************************************************************"<<endl;
                cout<<"Loss of year 2022 is = \t"<<lossOf2022<<endl;
                cout<<"Hotel has gained profit last year which is of amount = \t"<<lastYearProfit<<endl;
                cout<<"Profit and Loss of running year:"<<endl;
                cout<<"January\tRs."<<jan<<"    Profit"<<endl;
                cout<<"February\tRs."<<feb<<"    Profit"<<endl;
                cout<<"March\tRs."<<march<<"    Profit"<<endl;
                cout<<"April\tRs."<<april<<"   Year's Biggest  Profit"<<endl;
                cout<<"May\tRs."<<may<<"    Profit"<<endl;
                cout<<"June\tRs."<<june<<"    Profit"<<endl;
                cout<<"July\tRs."<<july<<"    Profit"<<endl;
                cout<<"August\tRs."<<august<<"    Profit"<<endl;
                cout<<"September\tRs."<<sep<<"    Loss"<<endl;
                cout<<"October\tRs."<<oct<<"    loss"<<endl;
                cout<<"November\tRs."<<nov<<"    Profit"<<endl;
    

}
void reviews()
{
                cout<<"*****************************************************************"<<endl;
                cout<<"              CUSTOMER   REVIEWS"<<endl;
                cout<<"*****************************************************************"<<endl;
                cout<<"Kinza Junaid"<<endl;
                cout<<"\t The management of grand marina is excellent.Their food is very delicious."<<endl;
                cout<<"\t It's interior is very attractive."<<endl;
                cout<<"Maryam Rehman"<<endl;
                cout<<"\t Food quality and the taste is very awesome.Services 100 out of 100."<<endl;
                cout<<"\t Ambiance is also satisfactory."<<endl;
                cout<<"Tanzeel Mohsin"<<endl;
                cout<<"\t The hotel is perfect for tourists wanting easy access to local sites. "<<endl;
                cout<<"\t Everything is in walking distance or a short drive away."<<endl;
}
void rooms(int esize,string user,string pwd,int input,int input1,string unbookedRooms,int r,string bookedRooms[])
{
                cout<<"**************************************************************"<<endl;
                cout<<"               ROOMS  INFORMATION"<<endl;
                cout<<"*************************************************************"<<endl;
                cout<<left<<setw(15)<<"\t"
                <<setw(10)<<"Booked Rooms"
                <<setw(10)<<"\t"
                <<setw(10)<<"Unbooked Rooms"
                <<setw(10)<<"\n";
                unbookedRooms=10-r;
               
                    for(int i=0;i<5;i++)
                     {
                    
                         cout<<left<<setw(15)<<"\n"
                         <<setw(10)<<"\t"
                         <<setw(10)<<bookedRooms[i]
                         <<setw(10)<<"\t"
                         <<setw(10)<<unbookedRooms<<"Rooms are still unbooked:";
                        
                     }
}
void complain(string customerData[][10],string customerComplain[][8])
{
    for(int j=0;j<8;j++)
    {
        if(customerComplain[0][j]=="N")
        {
            cout<<"Enter your name:"<<endl;
            cin>>customerComplain[0][j];
            cin.ignore(256,'\n');
            cout<<"Enter your complain:"<<endl;
            getline(cin,customerComplain[1][j]);
            cout<<"Your complain has been recorded!"<<endl;
            break;
            
        }
    }
    

}
bool loadData(string employeeData[][10])
{
    system("cls");

    ifstream fin;
    fin.open("C:/Users/dell/Documents/employeedata.txt");
    int j=0;

    if(!fin)
    {
        return false;
    }
    
    while(!fin.eof())
    {
             getline(fin,employeeData[0][j],',');
             getline(fin,employeeData[1][j],',');
             getline(fin,employeeData[2][j],',');
             getline(fin,employeeData[3][j],',');
             getline(fin,employeeData[4][j],'.');
             

             j++;
             
        
    

    }
        fin.close();
        return true;


}
bool saveData(string employeeData[][10])
{
    system("cls");

    ofstream fout("C:/Users/dell/Documents/employeedata1.txt");
    if(!fout)
    {
        return false;
    }
    for(int j=0;j<10;j++)
    {
        if(employeeData[0][j]!="")
        {
            fout<< employeeData[0][j]<<",";
            fout<< employeeData[1][j]<<",";
            fout<< employeeData[2][j]<<",";
            fout<< employeeData[3][j]<<",";
            fout<< employeeData[4][j];
            fout<<endl;


        }
    }
        fout.close();
        return true;
}
bool deleteData(string employeeData[][10], int esize)
{
    system("cls");

    ofstream fout("C:/Users/dell/Documents/employeedata1.txt");
    if(!fout)
    {
        return false;
    }
    for(int j=0;j<esize;j++)
    {
        if(employeeData[0][j]!="")
        {
            fout<< employeeData[0][j]<<",";
            fout<< employeeData[1][j]<<",";
            fout<< employeeData[2][j]<<",";
            fout<< employeeData[3][j]<<",";
            fout<< employeeData[4][j];
            fout<<endl;


        }
    }
}




            

         
         



            

         
         
